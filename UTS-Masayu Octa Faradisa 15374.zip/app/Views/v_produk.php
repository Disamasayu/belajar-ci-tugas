<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Ini Halaman Produk
<?= $this->endSection() ?>